import { Fragment } from "react"
import Header from "../components/Header/Header"
import CTouch from "../components/CTouch/CTouch"


const ContactUs = () => {
  return (
    <Fragment>
      <Header/>
      <CTouch/>

    </Fragment>
   
  )
}

export default ContactUs



