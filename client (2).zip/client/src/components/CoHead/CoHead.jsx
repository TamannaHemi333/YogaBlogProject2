

const CoHead = () => {
  return (
    <div>CoHead</div>
  )
}

export default CoHead