import { Fragment } from "react";
import "./PHead.css";


const PHead = () => {
  return (
    <Fragment>
        <div className="container1">
          
        <div className="aboutUs">ABOUT US</div>
        </div>
    </Fragment>
   
  )
}

export default PHead