import React, { Fragment } from "react";
import './P1Head.css';

const P1Head = () => {
  return (
    <Fragment>
      <div className="portfolio-container">
        <div className="portfolio-header">Portfolio</div>
      </div>
    </Fragment>
  );
};

export default P1Head;
